package com.parkingslot.bigthinkx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingslotprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
